﻿using System;
using Projeto.Avaliacao.API.Dominio.Entidades;

namespace Projeto.Avaliacao.API.Dominio.Interfaces
{
    public interface IProdutoEntregaRepositorio : IBaseRepositorio<ProdutoEntrega>
    {
    }
}
