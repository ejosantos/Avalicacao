﻿using Projeto.Avaliacao.API.Dominio.Entidades;

namespace Projeto.Avaliacao.API.Dominio.Interfaces
{
    public interface IProdutoRepositorio : IBaseRepositorio<Produto>
    {
    }
}
