﻿using Projeto.Avaliacao.API.Dominio.Entidades;

namespace Projeto.Avaliacao.API.Dominio.Interfaces
{
    public interface IImportacaoRepositorio : IBaseRepositorio<Importacao>
    {
    }
}
